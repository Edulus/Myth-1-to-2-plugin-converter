"""Mesh (`mesh`) tag headers for TFL and Myth II.

A mesh is a playable map. Its 1024-byte header sits at the start of the tag body
and points at everything else the map needs -- terrain, markers, map actions,
and the string lists the game shows in its menus.

Ported from mythextract ``scripts/mesh_tag.py`` @ c747909 (``MeshHeaderFmt`` and
``MeshHeaderFmtTFL``). Both are 1024 bytes, which makes the difference between
them easy to miss: **the same offset means different things in the two games.**
The divergence starts 76 bytes in --

    offset 76   TFL: render_variables_tag     Myth II: connector_tag

-- and the two layouts never re-converge. TFL has `teams_*` and `annotation_*`
blocks where Myth II has team/lighting colour fields, and Myth II adds a long
run of fields (reverb, connectors, cutscene filenames, fog, narration) that TFL
has no room for, ending in 730 bytes of padding on the TFL side.

Offsets stored *inside* the body are relative to the end of this header
(mythextract ``get_offset``: ``TAG_HEADER_SIZE + MESH_HEADER_SIZE + offset``),
which is why moving a mesh tag between containers does not require rewriting it.
"""

import enum
import struct

from . import codec, formats

MESH_HEADER_SIZE = 1024


class MeshFlags(enum.IntFlag):
    """mythextract scripts/mesh_tag.py:125-155 (``MeshFlags``).

    The low bits are the netgame types the map supports; the useful one here is
    ``SINGLE_PLAYER_MAP``.
    """

    BODY_COUNT = 1 << 0
    STEAL_THE_BACON = 1 << 1
    LAST_MAN_ON_THE_HILL = 1 << 2
    SCAVENGER_HUNT = 1 << 3
    FLAG_RALLY = 1 << 4
    CAPTURE_THE_FLAG = 1 << 5
    BALLS_ON_PARADE = 1 << 6
    TERRITORIES = 1 << 7
    CAPTURES = 1 << 8
    KING_OF_THE_HILL = 1 << 9
    STAMPEDE = 1 << 10
    ASSASSIN = 1 << 11
    HUNTING = 1 << 12
    CUSTOM = 1 << 13
    KING_OF_THE_HILL_TFL = 1 << 14
    KING_OF_THE_MAP = 1 << 15
    SINGLE_PLAYER_MAP = 1 << 16
    SUPPORTS_UNIT_TRADING = 1 << 17
    SUPPORTS_VETERANS = 1 << 18
    HAS_LIMITED_TERRAIN_VISIBILITY = 1 << 19
    IS_COMPLETE = 1 << 20
    CAN_BE_USED_BY_DEMO = 1 << 21
    LEAVES_OVERHEAD_MAP_CLOSED = 1 << 22
    IS_TRAINING_MAP = 1 << 23
    CAN_CATCH_FIRE = 1 << 24
    HAS_CEILING = 1 << 25
    HAS_TERRAIN_FOLLOWING_CAMERA = 1 << 26
    OVERHEAD_MAP_DOESNT_SCROLL = 1 << 27
    MODELS_DONT_LIMIT_RENDERING = 1 << 28
    USES_ANTICLUMP = 1 << 29
    USES_VTFL = 1 << 30
    REQUIRES_PLUGIN = 1 << 31


NETGAME_FLAGS = (
    MeshFlags.BODY_COUNT
    | MeshFlags.STEAL_THE_BACON
    | MeshFlags.LAST_MAN_ON_THE_HILL
    | MeshFlags.SCAVENGER_HUNT
    | MeshFlags.FLAG_RALLY
    | MeshFlags.CAPTURE_THE_FLAG
    | MeshFlags.BALLS_ON_PARADE
    | MeshFlags.TERRITORIES
    | MeshFlags.CAPTURES
    | MeshFlags.KING_OF_THE_HILL
    | MeshFlags.STAMPEDE
    | MeshFlags.ASSASSIN
    | MeshFlags.HUNTING
    | MeshFlags.CUSTOM
    | MeshFlags.KING_OF_THE_HILL_TFL
    | MeshFlags.KING_OF_THE_MAP
)

# --- TFL mesh header, 1024 bytes ---------------------------------------------
# mythextract scripts/mesh_tag.py:277-353 (``MeshHeaderFmtTFL``).
TFLMeshHeader = codec.Struct(
    "TFLMeshHeader",
    [
        ("4s", "landscape_collection_tag"),
        ("4s", "media_tag"),
        ("H", "submesh_width"),
        ("H", "submesh_height"),
        ("L", "mesh_offset"),
        ("L", "mesh_size"),
        ("4x", None),  # runtime: mesh_ptr
        ("L", "data_offset"),
        ("L", "data_size"),
        ("4x", None),  # runtime: data_ptr
        ("L", "marker_palette_entries"),
        ("L", "marker_palette_offset"),
        ("L", "marker_palette_size"),
        ("4x", None),  # runtime: marker_palette_ptr
        ("L", "marker_count"),
        ("L", "markers_offset"),
        ("L", "markers_size"),
        ("4x", None),  # runtime: markers_ptr
        ("4s", "mesh_lighting_tag"),
        ("4s", "render_variables_tag"),  # <- Myth II has connector_tag here
        ("L", "flags"),
        ("4s", "particle_system_tag"),
        ("L", "team_count"),
        ("L", "teams_offset"),  # TFL only
        ("L", "teams_size"),  # TFL only
        ("4x", None),  # runtime: teams_ptr
        ("L", "annotation_count"),  # TFL only
        ("L", "annotation_offset"),  # TFL only
        ("L", "annotation_size"),  # TFL only
        ("4x", None),  # runtime: annotations_ptr
        ("8s", "edge_of_mesh_buffer_zones"),
        ("4s", "global_ambient_sound_tag"),
        ("L", "map_action_count"),
        ("L", "map_actions_offset"),
        ("L", "map_action_buffer_size"),
        ("4s", "map_description_string_list_tag"),
        ("4s", "postgame_collection_tag"),
        ("4s", "pregame_collection_tag"),
        ("4s", "overhead_map_collection_tag"),
        ("4s", "next_mesh"),
        ("4s", "next_mesh_alternate"),
        ("4s", "cutscene_tag_pregame"),
        ("4s", "cutscene_tag_success"),
        ("4s", "cutscene_tag_failure"),
        ("4s", "pregame_storyline_tag"),
        ("4s", "storyline_string_tags_2"),
        ("4s", "storyline_string_tags_3"),
        ("4s", "storyline_string_tags_4"),
        ("L", "media_coverage_region_offset"),
        ("L", "media_coverage_region_size"),
        ("4x", None),  # runtime: media_coverage_region_ptr
        ("L", "mesh_LOD_data_offset"),
        ("L", "mesh_LOD_data_size"),
        ("4x", None),  # runtime: mesh_LOD_data_ptr
        ("8s", "global_tint_color"),
        ("h", "global_tint_fraction"),
        ("H", "pad"),
        ("4s", "wind_tag"),
        ("4s", "screen_collection_tags_1"),
        ("4s", "screen_collection_tags_2"),
        ("4s", "screen_collection_tags_3"),
        ("8s", "blood_color"),
        ("4s", "picture_caption_string_list_tag"),
        ("4s", "narration_sound_tag"),
        ("4s", "win_ambient_sound_tag"),
        ("4s", "loss_ambient_sound_tag"),
        ("730x", None),  # unused -- Myth II fills this region with real fields
        ("2x", None),  # runtime: map_description_string_index
        ("2x", None),  # runtime: overhead_map_collection_index
        ("2x", None),  # runtime: landscape_collection_index
        ("2x", None),  # runtime: global_ambient_sound_index
        ("2x", None),  # runtime: media_type
        ("16x", None),  # editor_data
    ],
)

# --- Myth II mesh header, 1024 bytes -----------------------------------------
# mythextract scripts/mesh_tag.py:165-276 (``MeshHeaderFmt``).
SBMeshHeader = codec.Struct(
    "SBMeshHeader",
    [
        ("4s", "landscape_collection_tag"),
        ("4s", "media_tag"),
        ("H", "submesh_width"),
        ("H", "submesh_height"),
        ("L", "mesh_offset"),
        ("L", "mesh_size"),
        ("4x", None),  # runtime: mesh_ptr
        ("L", "data_offset"),
        ("L", "data_size"),
        ("4x", None),  # runtime: data_ptr
        ("L", "marker_palette_entries"),
        ("L", "marker_palette_offset"),
        ("L", "marker_palette_size"),
        ("4x", None),  # runtime: marker_palette_ptr
        ("L", "marker_count"),
        ("L", "markers_offset"),
        ("L", "markers_size"),
        ("4x", None),  # runtime: markers_ptr
        ("4s", "mesh_lighting_tag"),
        ("4s", "connector_tag"),  # <- TFL has render_variables_tag here
        ("L", "flags"),
        ("4s", "particle_system_tag"),
        ("L", "team_count"),
        ("h", "dark_fraction"),
        ("h", "light_fraction"),
        ("8s", "dark_color"),
        ("8s", "light_color"),
        ("l", "transition_point"),
        ("h", "ceiling_height"),
        ("B", "min_vtfl_version"),
        ("B", "max_vtfl_version"),
        ("8s", "edge_of_mesh_buffer_zones"),
        ("4s", "global_ambient_sound_tag"),
        ("L", "map_action_count"),
        ("L", "map_actions_offset"),
        ("L", "map_action_buffer_size"),
        ("4s", "map_description_string_list_tag"),
        ("4s", "postgame_collection_tag"),
        ("4s", "pregame_collection_tag"),
        ("4s", "overhead_map_collection_tag"),
        ("4s", "next_mesh"),
        ("4s", "next_mesh_alternate"),
        ("4s", "cutscene_tag_pregame"),
        ("4s", "cutscene_tag_success"),
        ("4s", "cutscene_tag_failure"),
        ("4s", "pregame_storyline_tag"),
        ("4s", "storyline_string_tags_2"),
        ("4s", "storyline_string_tags_3"),
        ("4s", "storyline_string_tags_4"),
        ("L", "media_coverage_region_offset"),
        ("L", "media_coverage_region_size"),
        ("4x", None),  # runtime: media_coverage_region_ptr
        ("L", "mesh_LOD_data_offset"),
        ("L", "mesh_LOD_data_size"),
        ("4x", None),  # runtime: mesh_LOD_data_ptr
        ("8s", "global_tint_color"),
        ("h", "global_tint_fraction"),
        ("H", "pad"),
        ("4s", "wind_tag"),
        ("4s", "screen_collection_tags_1"),
        ("4s", "screen_collection_tags_2"),
        ("4s", "screen_collection_tags_3"),
        ("8s", "blood_color"),
        ("4s", "picture_caption_string_list_tag"),
        ("4s", "narration_sound_tag"),
        ("4s", "win_ambient_sound_tag"),
        ("4s", "loss_ambient_sound_tag"),
        # Everything from here down is Myth II only; TFL has padding.
        ("L", "reverb_environment"),
        ("f", "reverb_volume"),
        ("f", "reverb_decay_time"),
        ("f", "reverb_damping"),
        ("L", "connector_count"),
        ("l", "connectors_offset"),
        ("L", "connectors_size"),
        ("4x", None),  # runtime: connectors_ptr
        ("64s", "cutscene_file_pregame"),
        ("64s", "cutscene_file_success"),
        ("64s", "cutscene_file_failure"),
        ("4s", "hints_string_list_tag"),
        ("8s", "fog_color"),
        ("f", "fog_density"),
        ("4s", "difficulty_level_override_string_list_tag"),
        ("4s", "team_names_override_string_list_tag"),
        ("32s", "plugin_name"),
        ("L", "extra_flags"),
        ("4s", "win_narration_collection_tag"),
        ("4s", "loss_narration_collection_tag"),
        ("4s", "win_narration_storyline_tag_tag"),
        ("4s", "loss_narration_storyline_tag"),
        ("4s", "win_narration_caption_string_list_tag"),
        ("4s", "loss_narration_caption_string_list_tag"),
        ("4s", "win_narration_sound_tag"),
        ("4s", "loss_narration_sound_tag"),
        ("f", "minimum_zoom_factor"),
        ("406x", None),  # unused
        ("2x", None),  # runtime: connector_type
        ("2x", None),  # runtime: map_description_string_index
        ("2x", None),  # runtime: overhead_map_collection_index
        ("2x", None),  # runtime: landscape_collection_index
        ("2x", None),  # runtime: global_ambient_sound_index
        ("2x", None),  # runtime: media_type
        ("2x", None),  # runtime: hints_string_list_index
        ("4s", "editor_data_cookie"),
        ("L", "editor_data_size"),
        ("L", "editor_data_offset"),
        ("4x", None),  # editor_data_unused
    ],
)

MESH_HEADER_BY_VERSION = {formats.TFL: TFLMeshHeader, formats.SB: SBMeshHeader}

assert TFLMeshHeader.size == MESH_HEADER_SIZE, TFLMeshHeader.size
assert SBMeshHeader.size == MESH_HEADER_SIZE, SBMeshHeader.size


def parse_header(body, game_version):
    """Parse the mesh header from the *body* of a mesh tag.

    The body already excludes the 64-byte tag header, so the mesh header starts
    at offset 0 here -- unlike mythextract, which parses from whole tag files and
    so offsets everything by ``TAG_HEADER_SIZE``.
    """
    if len(body) < MESH_HEADER_SIZE:
        raise ValueError(
            f"mesh body is {len(body)} bytes, need at least {MESH_HEADER_SIZE}"
        )
    return MESH_HEADER_BY_VERSION[game_version].unpack(body)


def is_single_player(header):
    """mythextract scripts/mesh_tag.py:745-746."""
    return bool(header.flags & MeshFlags.SINGLE_PLAYER_MAP)


def netgame_types(header):
    """The multiplayer game types this mesh supports."""
    return [flag for flag in MeshFlags if flag & NETGAME_FLAGS and header.flags & flag]


def body_offset(offset):
    """Resolve an offset stored inside a mesh header to a position in the body.

    Offsets are relative to the end of the mesh header (mythextract
    ``get_offset``, which adds ``TAG_HEADER_SIZE`` on top because it works with
    whole tag files; we work with bodies).
    """
    return MESH_HEADER_SIZE + offset


def referenced_tags(header, game_version):
    """Every ``(tag_type, tag_id)`` this mesh header points at directly.

    Only the fixed header fields -- markers and map actions carry more IDs in
    variable-length blocks, which the mesh *body* converter will need to walk.
    Field-to-type mapping follows mythextract ``scripts/tag2local.py:157-176``.
    Unset IDs (all 0xFF or all 0x00) are skipped.
    """
    fields = [
        (b"stli", "map_description_string_list_tag"),
        (b"text", "pregame_storyline_tag"),
        (b"stli", "picture_caption_string_list_tag"),
        (b".256", "landscape_collection_tag"),
        (b".256", "overhead_map_collection_tag"),
        (b".256", "postgame_collection_tag"),
        (b".256", "pregame_collection_tag"),
        (b"wind", "wind_tag"),
        (b"meli", "mesh_lighting_tag"),
        (b"soun", "narration_sound_tag"),
        (b"amso", "global_ambient_sound_tag"),
        (b"part", "particle_system_tag"),
        (b"medi", "media_tag"),
    ]
    if game_version == formats.SB:
        fields += [
            (b"conn", "connector_tag"),
            (b"stli", "hints_string_list_tag"),
            (b"stli", "difficulty_level_override_string_list_tag"),
            (b"stli", "team_names_override_string_list_tag"),
        ]

    found = []
    for tag_type, field in fields:
        value = getattr(header, field, None)
        if value and not codec.all_on(value) and not codec.all_off(value):
            found.append((tag_type, value, field))
    return found


# --- Markers, marker palette, map actions -------------------------------------
#
# Everything below is *shared* between TFL and Myth II -- one struct each, no
# TFL/SB variant -- which is the opposite of the header above. Verified three
# ways: mythextract's own struct declarations (``MarkerHeadFmt``,
# ``MarkerPaletteEntryFmt``, ``ActionHeadFmt``, all read without a
# game-version branch), and two independent community tools that ported real
# TFL levels to Myth II by copying these three structures byte-for-byte --
# "Iron's Mesh Converter" (Mac and Windows builds, both with source,
# distributed with permission at
# tain.totalcodex.net/items/show/mesh-converter-mac-and-windows-w-source-code).
# See NOTES.md section 14.
#
# What is *not* shared: the map-action **parameter type codes**. TFL's
# ``ParamType`` numbering is missing the slot Myth II uses for a standalone
# ``PROJECTILE`` type, so every TFL code from 12 up means something different
# from the same numeric code in Myth II. That mismatch is a plausible direct
# cause of the ``EXCEPTION_ACCESS_VIOLATION`` inside the engine's
# ``byte_swap_data`` seen when loading an otherwise-converted mesh: a
# misread parameter type means a misread element count, which desyncs every
# subsequent read in the buffer. ``resolve_param_type`` and
# ``param_data_length`` exist to fix exactly that, ported from mythextract's
# own (read-side) handling of it in ``parse_map_actions``
# (scripts/mesh_tag.py:1285-1296) and cross-checked against both community
# tools' independently-arrived-at ``type++`` fixups for the same value range.

MARKER_HEAD_SIZE = 64
MARKER_PALETTE_ENTRY_SIZE = 32
MAP_ACTION_HEAD_SIZE = 64

# mythextract scripts/mesh_tag.py:658-673 (``MarkerHeadFmt``). Decoders for
# position/angle scale factors are dropped -- this project's codec does not
# do value decoding (see codec.py) -- since a structural pass-through never
# needs the scaled float value, only the raw bytes.
MarkerHead = codec.Struct(
    "MarkerHead",
    [
        ("L", "flags"),
        ("H", "type"),  # MarkerType
        ("H", "palette_index"),
        ("H", "id"),
        ("H", "min_difficulty"),
        ("L", "pos_x"),
        ("L", "pos_y"),
        ("l", "pos_z"),
        ("8x", None),
        ("H", "yaw"),
        ("2x", None),
        ("2x", None),
        ("20x", None),
        ("6x", None),
    ],
)

# mythextract scripts/mesh_tag.py:677-686 (``MarkerPaletteEntryFmt``).
MarkerPaletteEntry = codec.Struct(
    "MarkerPaletteEntry",
    [
        ("H", "type"),  # MarkerType
        ("H", "flags"),
        ("4s", "marker_tag"),  # the tag reference this palette slot resolves to
        ("h", "team_index"),
        ("2x", None),
        ("L", "netgame_flags"),
        ("10x", None),
        ("6x", None),
    ],
)

# mythextract scripts/mesh_tag.py:111-122 (``ActionHeadFmt``).
MapActionHead = codec.Struct(
    "MapActionHead",
    [
        ("H", "id"),
        ("H", "expiration_mode"),
        ("4s", "type"),  # the action kind, e.g. b'soun' -- not a tag reference
        ("L", "flags"),
        ("L", "trigger_time_lower_bound"),
        ("L", "trigger_time_delta"),
        ("H", "num_params"),
        ("H", "size"),
        ("L", "offset"),
        ("H", "indent"),
        ("34x", None),
    ],
)

assert MarkerHead.size == MARKER_HEAD_SIZE, MarkerHead.size
assert MarkerPaletteEntry.size == MARKER_PALETTE_ENTRY_SIZE, MarkerPaletteEntry.size
assert MapActionHead.size == MAP_ACTION_HEAD_SIZE, MapActionHead.size


class MarkerType(enum.IntEnum):
    """mythextract scripts/mesh_tag.py:402-414. 12 valid values (0-11); a
    stored type of 12 or more marks the end of real data in at least one
    community tool's experience with loose TFL mesh files (Iron's Mesh
    Converter, ``load_tfl``) -- consistent with this being one past the
    highest valid member, ``ANIMATION``."""

    OBSERVER = 0
    SCENERY = 1
    UNKNOWN_1 = 2
    UNIT = 3
    UNKNOWN_2 = 4
    AMBIENT_SOUND = 5
    MODEL = 6
    UNKNOWN_3 = 7
    UNKNOWN_4 = 8
    PROJECTILE = 9
    LOCAL_PROJECTILE_GROUP = 10
    ANIMATION = 11


# mythextract scripts/mesh_tag.py:415-423 (``Marker2Tag``). Types absent here
# (OBSERVER, the UNKNOWN_* slots) have no palette tag to look up.
MARKER_TYPE_TO_TAG = {
    MarkerType.SCENERY: b"scen",
    MarkerType.UNIT: b"unit",
    MarkerType.AMBIENT_SOUND: b"amso",
    MarkerType.MODEL: b"mode",
    MarkerType.PROJECTILE: b"proj",
    MarkerType.LOCAL_PROJECTILE_GROUP: b"lpgr",
    MarkerType.ANIMATION: b"anim",
}


class ParamType(enum.IntEnum):
    """mythextract scripts/mesh_tag.py:688-709 (``ParamType``). This is Myth
    II's numbering; a raw TFL value needs `resolve_param_type` first."""

    FLAG = 0
    STRING = 1
    MONSTER_IDENTIFIER = 2
    ACTION_IDENTIFIER = 3
    ANGLE = 4
    INTEGER = 5
    WORLD_DISTANCE = 6
    FIELD_NAME = 7
    FIXED = 8
    PROJECTILE = 9
    STRING_LIST = 10
    SOUND = 11
    PROJECTILE_OR_WORLD_POINT_2D = 12  # TFL = WORLD_POINT_2D / SB = PROJECTILE
    WORLD_POINT_2D = 13
    WORLD_RECTANGLE_2D = 14
    OBJECT_IDENTIFIER = 15
    MODEL_IDENTIFIER = 16
    SOUND_SOURCE_IDENTIFIER = 17
    WORLD_POINT_3D = 18
    LOCAL_PROJECTILE_GROUP_IDENTIFIER = 19
    MODEL_ANIMATION_IDENTIFIER = 20


# Parameter types that hold a tag reference as their element data, and the
# marker/tag type that reference resolves against. mythextract
# scripts/mesh_tag.py:424-435 (``param_id_marker``); STRING_LIST and
# ACTION_IDENTIFIER are deliberately excluded -- a string-list reference is a
# stli tag id but is looked up directly, and an action identifier refers to
# another map action in the same mesh, never a tag.
PARAM_TYPE_TAG = {
    ParamType.MONSTER_IDENTIFIER: b"unit",
    ParamType.SOUND_SOURCE_IDENTIFIER: b"amso",
    ParamType.OBJECT_IDENTIFIER: b"proj",
    ParamType.MODEL_IDENTIFIER: b"mode",
    ParamType.LOCAL_PROJECTILE_GROUP_IDENTIFIER: b"lpgr",
    ParamType.MODEL_ANIMATION_IDENTIFIER: b"anim",
    ParamType.PROJECTILE: b"proj",
    ParamType.SOUND: b"soun",
}


def resolve_param_type(raw_type, game_version):
    """The true semantic `ParamType` for a stored raw type code.

    TFL and Myth II share one enum, but TFL's on-disk numbering omits the slot
    Myth II uses for a standalone ``PROJECTILE`` type, so every TFL code from
    12 up means something different from the same numeric code in Myth II.
    Ported from mythextract's ``parse_map_actions``
    (scripts/mesh_tag.py:1285-1296), which already gets this right for
    *reading* a TFL mesh; this is the same table.

    Raises ``ValueError`` if ``raw_type`` is not a known code at all (not just
    a TFL/SB ambiguity) -- that is data we do not understand, not data we can
    silently reinterpret.
    """
    canonical = ParamType(raw_type)
    if game_version != formats.TFL:
        return canonical
    if canonical == ParamType.PROJECTILE_OR_WORLD_POINT_2D:
        return ParamType.WORLD_POINT_2D
    if canonical == ParamType.WORLD_RECTANGLE_2D:
        return ParamType.OBJECT_IDENTIFIER
    if canonical == ParamType.MODEL_IDENTIFIER:
        return ParamType.SOUND_SOURCE_IDENTIFIER
    if canonical == ParamType.WORLD_POINT_3D:
        return ParamType.LOCAL_PROJECTILE_GROUP_IDENTIFIER
    return canonical


def _align(boundary, value):
    """mythextract scripts/mesh_tag.py:722-723 (``align``)."""
    return (value + boundary - 1) & ~(boundary - 1)


def param_data_length(param_type, count):
    """Bytes of parameter data following a param's 8-byte header (type, count,
    name), given its true semantic type and stored element count.

    Ported from mythextract's sizing rules in ``parse_map_actions``
    (scripts/mesh_tag.py:1298-1335). Deliberately returns only a byte count,
    not decoded values: converting a param never needs to touch its data,
    only (sometimes) its type code, so there is nothing to gain from decoding
    the numbers only to re-encode them unchanged. Cross-checked against the
    three worked examples in docs/ActionParamElementFormat.txt.
    """
    if param_type == ParamType.STRING:
        return _align(4, count)
    if param_type in (ParamType.SOUND, ParamType.FIELD_NAME, ParamType.PROJECTILE):
        return count * 4
    if param_type == ParamType.WORLD_POINT_2D:
        return count * 2 * 4
    if param_type == ParamType.WORLD_POINT_3D:
        return count * 3 * 4
    if param_type in (ParamType.FIXED, ParamType.INTEGER, ParamType.WORLD_DISTANCE):
        return count * 4
    if param_type == ParamType.FLAG:
        return _align(4, count)
    return _align(2, count) * 2  # ANGLE and the default 2-byte-element types


def convert_tfl_map_actions(action_buffer, action_count):
    """Rewrite parameter type codes in a TFL map-action buffer to Myth II's.

    ``action_buffer`` is exactly ``map_action_buffer_size`` bytes, starting at
    a mesh's ``map_actions_offset`` (mythextract ``parse_map_actions`` slices
    the same span before walking it). Only the 2-byte type discriminator at
    the front of each parameter is ever rewritten; every other byte --
    counts, names, and all parameter data -- is copied unchanged, because a
    TFL-vs-Myth-II type mismatch changes what a code *means*, never how the
    data behind it is encoded.

    Returns ``(new_buffer, warnings)``. On an unrecognised parameter type,
    the rest of that action's parameters are left untouched and a warning is
    recorded, since the byte length of an unrecognised type cannot be
    trusted and guessing risks desyncing every later parameter.
    """
    warnings = []
    out = bytearray(action_buffer)
    action_head_end = action_count * MAP_ACTION_HEAD_SIZE

    for action in MapActionHead.unpack_many(action_buffer, 0, action_count):
        offset = action_head_end + action.offset
        remaining = action.num_params
        while remaining > 0:
            raw_type, count = struct.unpack_from(">HH", action_buffer, offset)
            try:
                semantic = resolve_param_type(raw_type, formats.TFL)
            except ValueError:
                warnings.append(
                    f"map action {action.id} ({codec.decode_string(action.type)}): "
                    f"unrecognised parameter type {raw_type}; left unconverted from "
                    f"here on, along with {remaining - 1} later parameter(s) in "
                    f"this action"
                )
                break
            new_raw = int(semantic)
            if new_raw != raw_type:
                struct.pack_into(">H", out, offset, new_raw)
            offset += 8 + param_data_length(semantic, count)
            remaining -= 1

    return bytes(out), warnings


# --- Terrain -----------------------------------------------------------------
#
# The one part of a mesh whose *size* changes between the games. Myth II packs
# 32x32 cells into a submesh where TFL packs 16x16, across identical ground --
# a submesh is 32 world units in both (NOTES.md section 15) -- so Myth II has
# double the linear terrain resolution and four times the cells.
#
# The cell struct grows too, but conveniently rather than awkwardly: a TFL cell
# is byte-for-byte the first 8 bytes of a Myth II cell.
#
#     height h | normal1 b | normal2 b | flags B | terrain_type B | first_obj H
#     ------------------------------ TFL ends here (8 bytes) ------------------
#     media_height h | model_index H
#     ------------------------------ Myth II ends here (12 bytes) -------------
#
# So converting a cell is appending four bytes, never unpacking and repacking.
# mythextract declares a single `MeshCellFmt` of exactly these eight fields
# (scripts/mesh_tag.py:73-82), and decoding real TFL bytes against the first six
# yields sensible values throughout -- flat start areas at constant height,
# smoothly varying normals, 0xFFFF "no object" sentinels.

TFL_CELLS_PER_SUBMESH_AXIS = 16
SB_CELLS_PER_SUBMESH_AXIS = 32
TFL_CELL_SIZE = 8
SB_CELL_SIZE = 12

# Myth II's "no model here" sentinel, seen in ~99% of cells in every native mesh.
NO_MODEL_INDEX = 0xFFFF

# TFL cell flags -> Myth II cell flags. The byte sits at the same offset in
# both games but does not mean the same: copied unchanged, TFL's 0x21 on
# Crow's Bridge's deck made Myth II leave the deck undrawn, so units on it
# walked on air (Keep, Q7). Each entry is the value Project Magma's ports
# (*The Fallen Levels v2*) most often hold where TFL holds the key, over all
# four Myth II cells of each TFL cell on the 11 levels they share with TFL.
# It matches their flags on 95.5% of cells, against 84.2% copied (NOTES.md
# section 23). Values not listed (0x00 among them) are kept.
TFL_TO_SB_CELL_FLAGS = {
    0x01: 0x00,
    0x10: 0x38,
    0x11: 0x3D,
    0x15: 0x3D,
    0x18: 0x00,
    0x19: 0x00,
    0x1D: 0x3D,
    0x20: 0x00,
    0x21: 0x20,
    0x28: 0x20,
    0x29: 0x20,
    0x3D: 0x00,
}
CELL_FLAGS_OFFSET = 4


def cell_counts(submesh_width, submesh_height, game_version):
    """``(columns, rows)`` of terrain cells for a mesh of this many submeshes."""
    axis = (
        TFL_CELLS_PER_SUBMESH_AXIS
        if game_version == formats.TFL
        else SB_CELLS_PER_SUBMESH_AXIS
    )
    return submesh_width * axis, submesh_height * axis


def upsample_terrain(terrain, submesh_width, submesh_height, media_height=0):
    """Convert a TFL terrain block into a Myth II one.

    Each TFL cell becomes the 2x2 block of Myth II cells covering the same
    ground. The top-left cell keeps the TFL height; the other three take the
    average of the TFL heights at their corners, so slopes stay slopes instead
    of becoming 2x2 steps. The flags are translated through
    `TFL_TO_SB_CELL_FLAGS`; every other field is copied unchanged.

    This matches Project Magma's hand port of Crow's Bridge (*The Fallen Levels
    v2*): their heights equal TFL's at the original points and sit halfway
    between them elsewhere, while their normals are copied, not blended or
    recomputed. Blending brought our mean height gap to their port from 48 to
    21 (NOTES.md section 20).

    ``media_height`` is a Myth II-only per-cell field with no TFL source. It is
    the height of the water *surface*, and is a single constant across nearly
    every native mesh, so it is passed in as one value rather than derived.

    Returns the new terrain bytes.
    """
    columns, rows = cell_counts(submesh_width, submesh_height, formats.TFL)
    expected = columns * rows * TFL_CELL_SIZE
    if len(terrain) < expected:
        raise ValueError(
            f"terrain block is {len(terrain)} bytes, need {expected} for a "
            f"{submesh_width}x{submesh_height}-submesh TFL mesh "
            f"({columns}x{rows} cells)"
        )

    # The four bytes Myth II adds to every cell. Identical for all of them, so
    # built once.
    suffix = struct.pack(">hH", media_height, NO_MODEL_INDEX)

    def cell(x, y):
        start = (y * columns + x) * TFL_CELL_SIZE
        source = bytearray(terrain[start : start + TFL_CELL_SIZE])
        flags = source[CELL_FLAGS_OFFSET]
        source[CELL_FLAGS_OFFSET] = TFL_TO_SB_CELL_FLAGS.get(flags, flags)
        return bytes(source)

    heights = [
        [struct.unpack_from(">h", terrain, (y * columns + x) * TFL_CELL_SIZE)[0] for x in range(columns)]
        for y in range(rows)
    ]

    def with_height(source, height):
        return struct.pack(">h", height) + source[2:] + suffix

    out = bytearray()
    for y in range(rows):
        below = min(y + 1, rows - 1)  # the last row has nothing below to blend with
        top = bytearray()
        bottom = bytearray()
        for x in range(columns):
            right = min(x + 1, columns - 1)
            source = cell(x, y)
            here, east = heights[y][x], heights[y][right]
            south, southeast = heights[below][x], heights[below][right]
            top += source + suffix
            top += with_height(source, (here + east) // 2)
            bottom += with_height(source, (here + south) // 2)
            bottom += with_height(source, (here + east + south + southeast) // 4)
        out += top
        out += bottom

    return bytes(out)


# World units per Myth II cell, the scale of a marker's pos_x and pos_y.
SB_CELL_WORLD_SIZE = 512

# Markers whose height is the ground under them. TFL appears to have placed
# these on the ground whatever pos_z said; Myth II uses pos_z, so a stale value
# leaves a bush floating or buried. Project Magma's port of Crow's Bridge puts
# all of them on its ground and leaves sounds, models and projectile groups be.
GROUNDED_MARKER_TYPES = {MarkerType.OBSERVER, MarkerType.SCENERY, MarkerType.UNIT}


def ground_height(terrain, columns, rows, x, y):
    """The ground's height at world point (x, y) on a Myth II terrain block.

    Each cell is two triangles, the split alternating like a chessboard: from
    top-left to bottom-right where column + row is even, the other way where it
    is odd. Measured on Crow's Bridge in *The Fallen Levels v2*, this puts 99%
    of Magma's scenery and units at their stored height exactly and the rest
    within 3; a single split direction or a bilinear blend misses by up to 45.
    """

    def at(cx, cy):
        cx, cy = min(max(cx, 0), columns - 1), min(max(cy, 0), rows - 1)
        return struct.unpack_from(">h", terrain, (cy * columns + cx) * SB_CELL_SIZE)[0]

    cx, cy = int(x // SB_CELL_WORLD_SIZE), int(y // SB_CELL_WORLD_SIZE)
    tx = x / SB_CELL_WORLD_SIZE - cx
    ty = y / SB_CELL_WORLD_SIZE - cy
    a, b = at(cx, cy), at(cx + 1, cy)
    c, d = at(cx, cy + 1), at(cx + 1, cy + 1)
    if (cx + cy) % 2 == 0:
        if tx >= ty:
            return a + (b - a) * tx + (d - b) * ty
        return a + (c - a) * ty + (d - c) * tx
    if tx + ty <= 1:
        return a + (b - a) * tx + (c - a) * ty
    return d + (c - d) * (1 - tx) + (b - d) * (1 - ty)


def place_markers_on_ground(markers, count, terrain, submesh_width, submesh_height):
    """Set each grounded marker's pos_z to the ground under it.

    ``markers`` is a mesh's marker block and ``terrain`` its converted Myth II
    terrain block. Returns ``(markers, moved)``: the new block, and how many
    markers changed height.
    """
    columns, rows = cell_counts(submesh_width, submesh_height, formats.SB)
    out = bytearray(markers)
    moved = 0
    for i, marker in enumerate(MarkerHead.unpack_many(markers, 0, count)):
        if marker.type not in GROUNDED_MARKER_TYPES:
            continue
        z = round(ground_height(terrain, columns, rows, marker.pos_x, marker.pos_y))
        if z != marker.pos_z:
            start = i * MARKER_HEAD_SIZE
            out[start : start + MARKER_HEAD_SIZE] = marker.replace(pos_z=z).encode()
            moved += 1
    return bytes(out), moved


def place_models_by_centre(markers, count, palette, palette_entries, centres):
    """Move each model marker from where TFL anchors a model to where Myth II
    does.

    TFL places a model by a corner, Myth II by its geometry's centre. Across
    the 17 levels of *The Fallen Levels v2* that pair with stock TFL levels,
    Magma moved every copy of a model by the same amount, and for nearly every
    model that amount is the geometry's (center_x, center_y) rounded to a whole
    Myth II cell, whatever way the model faces (NOTES.md section 17).

    ``palette`` is the mesh's marker palette, whose model entries are indexed
    by a model marker's ``palette_index``; ``centres`` maps a TFL model id to
    its geometry's centre. Returns ``(markers, moved, missing)``, ``missing``
    being the model ids with no known centre, whose markers are left alone.
    """
    entries = MarkerPaletteEntry.unpack_many(palette, 0, palette_entries)
    models = [e.marker_tag for e in entries if e.type == MarkerType.MODEL]
    out = bytearray(markers)
    moved, missing = 0, set()
    for i, marker in enumerate(MarkerHead.unpack_many(markers, 0, count)):
        if marker.type != MarkerType.MODEL or marker.palette_index >= len(models):
            continue
        model = models[marker.palette_index]
        if model not in centres:
            missing.add(model)
            continue
        dx, dy = (_whole_cells(c) for c in centres[model])
        if dx or dy:
            start = i * MARKER_HEAD_SIZE
            shifted = marker.replace(pos_x=marker.pos_x + dx, pos_y=marker.pos_y + dy)
            out[start : start + MARKER_HEAD_SIZE] = shifted.encode()
            moved += 1
    return bytes(out), moved, sorted(missing)


MODEL_WALL_STEP = 400
MODEL_BASE_TOLERANCE = 32


def lower_ground_beside_models(
    terrain, submesh_width, submesh_height, markers, count, palette, palette_entries, reaches
):
    """Drop the blended ground off a model's walls to the model's base.

    TFL drew a model over its ground, so a slope running up the side of a
    model left the model's wall in view. Myth II hides whatever is below the
    ground, and the points `upsample_terrain` blends in between TFL's put a
    slope a little higher than the wall: Crow's Bridge's bridge showed only
    its railings, the ground sagging away from them (Keep, Q7). Magma's port
    drops those points to the foot of the wall.

    So an in-between point inside a model's reach, whose TFL corners step at
    least `MODEL_WALL_STEP` and whose lowest corner is the model's base (its
    marker height, within `MODEL_BASE_TOLERANCE`), takes that lowest height.
    Across the 17 levels of *The Fallen Levels v2* that pair with stock TFL
    levels, this brings Crow's Bridge's 14 such points from a mean of 351
    off Magma's to 48 and Forest Heart's ent bridge's 44 from 2,339 to 1,885;
    under the other five models it touches it is a little nearer on the
    whole (NOTES.md section 22). Without the base condition, or with a
    gentler step, it is further off on most of them.

    ``markers`` must already be placed by centre; ``reaches`` maps a TFL
    model id to how far its geometry reaches from its centre, either way, in
    world units (`src.convert.plugin.model_reaches`). Returns
    ``(terrain, lowered)``.
    """
    columns, rows = cell_counts(submesh_width, submesh_height, formats.SB)

    def height(x, y):
        return struct.unpack_from(">h", terrain, (y * columns + x) * SB_CELL_SIZE)[0]

    def corners(i, size):
        # An odd index lies between two TFL points; at the far edge
        # `upsample_terrain` blended the last point with itself.
        return (i,) if i % 2 == 0 else (i - 1, min(i + 1, size - 2))

    entries = MarkerPaletteEntry.unpack_many(palette, 0, palette_entries)
    models = [e.marker_tag for e in entries if e.type == MarkerType.MODEL]
    out = bytearray(terrain)
    lowered = set()
    for marker in MarkerHead.unpack_many(markers, 0, count):
        if marker.type != MarkerType.MODEL or marker.palette_index >= len(models):
            continue
        reach = reaches.get(models[marker.palette_index])
        if not reach:
            continue
        # Strictly inside the reach: a point on its edge is the model's rim.
        x0 = max(int((marker.pos_x - reach) // SB_CELL_WORLD_SIZE) + 1, 0)
        x1 = min(-int(-(marker.pos_x + reach) // SB_CELL_WORLD_SIZE), columns)
        y0 = max(int((marker.pos_y - reach) // SB_CELL_WORLD_SIZE) + 1, 0)
        y1 = min(-int(-(marker.pos_y + reach) // SB_CELL_WORLD_SIZE), rows)
        for y in range(y0, y1):
            for x in range(x0, x1):
                if x % 2 == 0 and y % 2 == 0:
                    continue  # a TFL point, kept as it is
                around = [height(cx, cy) for cy in corners(y, rows) for cx in corners(x, columns)]
                low = min(around)
                if max(around) - low < MODEL_WALL_STEP or abs(low - marker.pos_z) > MODEL_BASE_TOLERANCE:
                    continue
                struct.pack_into(">h", out, (y * columns + x) * SB_CELL_SIZE, low)
                lowered.add((x, y))
    return bytes(out), len(lowered)


def _whole_cells(distance):
    """``distance`` rounded to the nearest whole Myth II cell, halves up."""
    return (distance + SB_CELL_WORLD_SIZE // 2) // SB_CELL_WORLD_SIZE * SB_CELL_WORLD_SIZE


def build_lod_data(submesh_width, submesh_height):
    """A Myth II mesh level-of-detail block, sized to the cell count.

    Every one of the 87 Myth II meshes surveyed -- 47 native campaign meshes and
    40 from a community TFL port -- carries this block at exactly half a byte
    per cell, and none has it empty, so it cannot simply be omitted.

    Its contents are rendering detail hints whose encoding is not understood
    here; real blocks are roughly half zero bytes with 0xF0 and 0xFF common.
    Zero-filling is the conservative choice: correctly sized, and uniform rather
    than randomly wrong.
    """
    columns, rows = cell_counts(submesh_width, submesh_height, formats.SB)
    return bytes((columns * rows) // 2)


def remap_marker_palette(palette_buffer, entry_count, id_map):
    """Rewrite each marker-palette entry's tag reference through ``id_map``.

    ``palette_buffer`` is exactly ``marker_palette_size`` bytes, starting at a
    mesh's ``marker_palette_offset``. The entry structure itself needs no
    conversion (see module note); only the 4-byte tag id each entry carries
    may need remapping, and only entries whose type resolves to a known tag
    type via `MARKER_TYPE_TO_TAG` carry one at all.

    Returns ``(new_buffer, warnings)``.
    """
    out = bytearray(palette_buffer)
    warnings = []

    for i in range(entry_count):
        offset = i * MARKER_PALETTE_ENTRY_SIZE
        entry = MarkerPaletteEntry.unpack(palette_buffer, offset)

        try:
            marker_type = MarkerType(entry.type)
        except ValueError:
            continue
        tag_type = MARKER_TYPE_TO_TAG.get(marker_type)
        if tag_type is None:
            continue
        if codec.all_on(entry.marker_tag) or codec.all_off(entry.marker_tag):
            continue

        mapped = id_map.map_id(tag_type, entry.marker_tag) if id_map else entry.marker_tag
        if mapped != entry.marker_tag:
            out[offset + 4 : offset + 8] = mapped

    return bytes(out), warnings
